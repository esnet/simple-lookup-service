package net.es.lookup.common.exception.internal;

public class DuplicateEntryException extends Exception{
    public DuplicateEntryException(String message){
        super(message);
    }
}