package net.es.lookup.common;

import java.util.Map;

public abstract class DeleteResponse extends Message {

    public DeleteResponse() {

        super();

    }


    public DeleteResponse(Map<String, Object> map) {

        super(map);

    }


}