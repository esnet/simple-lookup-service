package net.es.lookup.protocol.json;

import net.es.lookup.common.RegisterResponse;

import java.util.Map;

public class JSONRegisterResponse extends RegisterResponse {

    public JSONRegisterResponse() {

        super();

    }


    public JSONRegisterResponse(Map<String, Object> map) {

        super(map);

    }


}