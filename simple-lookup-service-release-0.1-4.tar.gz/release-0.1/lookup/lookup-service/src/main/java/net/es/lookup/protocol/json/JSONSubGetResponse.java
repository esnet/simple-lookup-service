package net.es.lookup.protocol.json;

import net.es.lookup.common.SubGetResponse;

import java.util.Map;

public class JSONSubGetResponse extends SubGetResponse {

    public JSONSubGetResponse() {

        super();

    }


    public JSONSubGetResponse(Map<String, Object> map) {

        super(map);

    }


}