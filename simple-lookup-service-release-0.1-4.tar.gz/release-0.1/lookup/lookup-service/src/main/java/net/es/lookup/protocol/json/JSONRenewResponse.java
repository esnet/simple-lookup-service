package net.es.lookup.protocol.json;


import net.es.lookup.common.RenewResponse;

import java.util.Map;

public class JSONRenewResponse extends RenewResponse {

    public JSONRenewResponse() {

        super();

    }


    public JSONRenewResponse(Map<String, Object> map) {

        super(map);

    }


}