/**
 * This interface defines the API between the REST API handling and the actual Lookup Service.
 *
 **/

package net.es.lookup.common;

public class LookupService {

    public RegisterResponse publishService(RegisterRequest registerRequest) {

        return null;

    }

    public DeleteResponse deleteService(DeleteRequest deleteRequest) {

        return null;

    }

    public RenewResponse renewService(RenewRequest renewRequest) {

        return null;

    }

    public Service getServiceByURI(String URI) {

        return null;

    }

    public QueryResponse query(QueryRequest queryRequest) {

        return null;

    }


}