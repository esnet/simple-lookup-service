package net.es.lookup.common.exception.internal;

public class DatabaseException extends Exception{
    public DatabaseException(String message){
        super(message);
    }
}