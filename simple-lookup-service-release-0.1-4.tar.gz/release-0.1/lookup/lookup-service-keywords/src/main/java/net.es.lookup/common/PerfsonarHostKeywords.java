package net.es.lookup.common;

/**
 * User: sowmya
 * Date: 9/25/12
 * Time: 1:37 PM
 */
public class PerfsonarHostKeywords extends RecordKeywords {

}
