package net.es.lookup.common.exception;

/**
 * User: sowmya
 * Date: 9/25/12
 * Time: 3:58 PM
 */
public class LSClientException extends Exception {

    public LSClientException(String message) {

        super(message);

    }

}
